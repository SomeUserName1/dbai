SELECT sname, rating FROM Sailors WHERE rating BETWEEN 3 AND 5;
SELECT sname, rating FROM Sailors WHERE rating BETWEEN SYMMETRIC 5 AND 3;