SELECT COUNT(*) FROM Sailors;
SELECT COUNT(*) AS num FROM Sailors;
SELECT MIN(rating) AS minimum, MAX(rating) AS maximum FROM Sailors;
