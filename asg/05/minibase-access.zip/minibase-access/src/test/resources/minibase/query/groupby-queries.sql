SELECT * FROM Sailors GROUP BY sname;
SELECT * FROM Sailors GROUP BY sname, rating;
SELECT * FROM Sailors GROUP BY ();