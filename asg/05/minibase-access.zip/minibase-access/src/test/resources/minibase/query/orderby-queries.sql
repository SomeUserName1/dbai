SELECT * FROM Sailors ORDER BY sname;
SELECT * FROM Sailors ORDER BY sname ASC;
SELECT * FROM Sailors ORDER BY sname, rating DESC;
SELECT * FROM Sailors ORDER BY sname ASC, rating DESC;