
package minibase.access.file;

import minibase.storage.buffer.PageType;

public final class RunPage implements PageType {
}
