
package minibase.access.file;

import minibase.query.evaluator.TupleIterator;

public class RunScan implements TupleIterator {

   @Override
   public boolean hasNext() {
      // #TODO implement this
      throw new UnsupportedOperationException("not yet implemented");
   }

   @Override
   public byte[] next() {
      // #TODO implement this
      throw new UnsupportedOperationException("not yet implemented");
   }

   @Override
   public void reset() {
      // #TODO implement this
      throw new UnsupportedOperationException("not yet implemented");
   }

   @Override
   public void close() {
      // #TODO implement this
      throw new UnsupportedOperationException("not yet implemented");
   }
}
