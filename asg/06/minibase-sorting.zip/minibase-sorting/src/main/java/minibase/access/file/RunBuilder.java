
package minibase.access.file;

import minibase.storage.buffer.BufferManager;

public final class RunBuilder {

   public RunBuilder(final BufferManager bufferManager, final int recordLength) {
      // #TODO implement this
      throw new UnsupportedOperationException("not yet implemented");
   }

   public void appendRecord(final byte[] record) {
      // #TODO implement this
      throw new UnsupportedOperationException("not yet implemented");
   }

   public Run finish() {
      // #TODO implement this
      throw new UnsupportedOperationException("not yet implemented");
   }
}
