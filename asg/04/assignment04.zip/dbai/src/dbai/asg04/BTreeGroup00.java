package dbai.asg04;

public final class BTreeGroup00 extends AbstractBTree {

   public BTreeGroup00(final int d) {
      super(d);
   }

   @Override
   protected boolean containsKey(final int nodeID, final int key) {
      // TODO implement this
      throw new UnsupportedOperationException("Not yet implemented.");
   }

   @Override
   protected long insertKey(final int nodeID, final int key) {
      // TODO implement this
      throw new UnsupportedOperationException("Not yet implemented.");
   }

   @Override
   protected boolean deleteKey(final int nodeID, final int key) {
      // TODO implement this
      throw new UnsupportedOperationException("Not yet implemented.");
   }
}
